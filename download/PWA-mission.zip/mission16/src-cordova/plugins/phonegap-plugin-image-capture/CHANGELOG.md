# Change Log

## [v1.1.2](https://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/tree/v1.1.2) (2017-09-21)
[Full Changelog](https://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/compare/v1.1.1...v1.1.2)

- 1.1.2 [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/5eff48fad6fbc640e38d29173f153306460bad48)
- :bookmark: Bumping plugin version to 1.1.2 [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/5f3b8a37373d384f9a154376259a3bc6104d764b)
- ⬆️ bump phonegap-plugin-media-stream to 1.2.0 [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/ec7c9b74b0662399b339f05e2a089609f285560b)
- ⬆️ bump pluginpub version to 0.0.9 [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/3808ff93f802f72a0fe30e298919ae2438c905f6)
- :sparkles: Added native error callback for takePhoto() [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/7c8134539b6911e2986aa1f8298eb764e8d134dc)
- Updating CHANGELOG [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/6274b7571caef684d4603eb223e93c7be92de4ab)

## [v1.1.1](https://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/tree/v1.1.1) (2017-08-16)
[Full Changelog](https://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/compare/v1.1.0...v1.1.1)

- 1.1.1 [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/c3bff9f710436ff335863faf31cab0fad4253eba)
- :bookmark: Bumping plugin version to 1.1.1 [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/6a12accc16235b2cb99829f9af40ba382850a42d)
- :poop: Fixing bad copy of files from XCode [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/12187061c8eb7cb4377b031049e34f33c0e4216e)
- Updating CHANGELOG [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/8a93eb1740301d2e613c41c9676c1e104e9fa802)

## [v1.1.0](https://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/tree/v1.1.0) (2017-08-16)
[Full Changelog](https://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/compare/v1.0.0...v1.1.0)

- 1.1.0 [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/6a799e491bce1a7affdfa0c57276d70a9be81b45)
- :bookmark: Bumping plugin version to 1.1.0 [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/135335cc18dfbc25a266d9ae2f9b5fa4d0a0b130)
- :arrow_up: Use media stream 1.1.0 or greater [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/5d582f13ce92828bf73f57f4c03b02283efdc5a9)
- :hammer: Moving common code to media-stream plugin [view commit](http://github.com/git@github.com:phonegap/phonegap-plugin-image-capture/commit/c7919fc1badb027e2c3aae858e7e4a10c0154f53)

# ChangeLog

