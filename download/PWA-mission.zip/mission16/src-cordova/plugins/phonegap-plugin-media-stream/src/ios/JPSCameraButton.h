//
//  JPSCameraButton.h
//  JPSImagePickerController
//
//  Created by JP Simard on 1/31/2014.
//  Copyright (c) 2014 JP Simard. All rights reserved.
//

#import <UIKit/UIKit.h>


IB_DESIGNABLE
@interface JPSCameraButton : UIButton
@end
