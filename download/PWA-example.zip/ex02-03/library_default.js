// 외부 공유할 기본 함수
const fnPlusNumbers = (pNum1, pNum2) => pNum1 + pNum2;

// 외부에서 기본 함수를 사용할 수 있도록 내보냄
export default fnPlusNumbers;