<!-- 라우터에 설정되지 않은 페이지를 선택할 때 안내문 표시-->
<template>
  <v-container>
    <v-row>
      <v-col cols="12" class="text-center mt-5">
        <h1 class="display-1 my-1">오류가 발생하였습니다!</h1>
        <p class="body-1">페이지를 찾을 수 없습니다.</p>
      </v-col>
    </v-row>
  </v-container>
</template>