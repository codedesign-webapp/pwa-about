<template>
  <v-app>
      <!-- 앱바색상을 primary(파랑색)로 설정하고 fixed로 위치 고정 -->
      <v-app-bar app color="primary" dark fixed>
        <!-- 좌측에 메뉴 아이콘 넣음 -->
        <v-app-bar-nav-icon></v-app-bar-nav-icon>
        <v-toolbar-title>마스터 페이지</v-toolbar-title>
        <!-- 우측에 추가메뉴 아이콘을 넣기 위해 v-spacer 엘리먼트 사용 -->
        <v-spacer></v-spacer>
        <v-btn icon>
          <v-icon>mdi-dots-vertical</v-icon>
        </v-btn>
      </v-app-bar>
      <v-content>
        <v-container>
          <!-- display-1/3, body-1/2 타이포그래피 서체 종류와 크기로 설정 -->
          <h1 class="display-1 my-5">안녕하세요</h1>
          <!-- my-4로 상하 안쪽여백 설정 -->
          <p class="body-2 my-4">마스터페이지입니다.</p>
          <v-divider></v-divider>
          <h1 class="display-3 my-4">안녕하세요</h1>
          <p class="body-1 my-4">마스터페이지입니다.</p>
        </v-container>
      </v-content>
      <!-- footer 색상을 secondary로 설정하고 fixed로 위치를 고정시킴 -->
      <v-footer color="secondary" dark fixed>
        <!-- mx-auto는 블럭레벨 엘리먼트의 내용을 가운데 정렬시킴 -->
        <div class="mx-auto">Copyright &copy;</div>
      </v-footer>
    </v-app>
</template>
<script>
  export default {
    name: 'App',
  }
</script>